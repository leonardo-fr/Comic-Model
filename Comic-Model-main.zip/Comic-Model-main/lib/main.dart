import 'package:commic_geek/screens/intro_screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: IntroScreen()
  ));
}

