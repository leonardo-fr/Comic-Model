package com.example.commic_geek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
